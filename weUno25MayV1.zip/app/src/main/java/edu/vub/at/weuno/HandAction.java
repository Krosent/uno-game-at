package edu.vub.at.weuno;

public interface HandAction {

    public boolean cardPlayed(Card card);

}
