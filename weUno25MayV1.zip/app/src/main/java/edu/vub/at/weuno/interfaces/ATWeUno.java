package edu.vub.at.weuno.interfaces;


import edu.vub.at.objects.coercion.Async;

/**
 * Interface that the AmbientTalk object needs to implement so that Java objects talk to it.
 */
public interface ATWeUno {
    @Async
    void connectPlayer(String username);
}
