package edu.vub.at.weuno.interfaces;

/**
 * Interface that the Java object implements with the methods that AmbientTalk objects call on it.
 */
public interface JWeUno {
    JWeUno registerAtApplication(ATWeUno uno);

    void updateConnectedGamersCounter(int counter);

    void disableConnectButton();

    void enableGameButton();

    // init game
    void initGame();

    // start game


    // finish game
    // verify end game

}
